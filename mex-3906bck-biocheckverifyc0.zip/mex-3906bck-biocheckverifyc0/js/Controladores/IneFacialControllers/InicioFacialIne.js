var app = angular.module("myApp");
app.controller("InicioFacialIneController", function ($scope, DOM, biocheck, bccatalogos, bcstorage) {
    //Es para saber si ya carg� la p�gina mediante un mensaje al parent del iframe
    postCancelarConteoller();
    //Controla la versi�n del front
    bcstorage.versionBiocheck = "1.4.9";
    bcstorage.versionSistema = "3.2.2.8";

    biocheck.checkService();
    $scope.procesando = biocheck.procesando("Captura rostro");
    $scope.correos = bccatalogos.domains;//Catalogos de email
    $scope.email = ''; //guardamos texto del campo de texto
    $scope.dominio = '@gmail.com'; //guardamos dominio seleccionado
    $scope.mostrarCorreoElectronico = false; //Aparece y desaparece el campo de email
    $scope.cargaCompleta = true; //Se debe activar a true cuando todo los componentes se carguen y se muestra el boton Siguiente
    $scope.msjerror = '';
    $scope.modalerrormensaje = biocheck.modalerrormensaje;
    $scope.modalerrormensaje2 = biocheck.modalerrormensaje2;
    $scope.cont = 0;
    $.connection.hub.url = bcstorage.hubUrl;
    //$scope.cancelar = biocheck.cancelar;
    $scope.isnotwhitelist = true;
    $scope.cont = 0;

    var ejecutivo = null;
    var biochkHub = $.connection.biocheckHub;
    var winPros = null;
    var guid = null;
    var obtenerVersionDespliegueExito = false;
    var respuestaCargada = false;

    //Variables reset escaner
    var intentosReiniciarEscaner = 0;
    var intentosResetEscanerDoc = 3;
    var esReintentoEscaner = false;

    var elem = document.querySelector('.js-switch');
    var correoElectronicoSwitch = new Switchery(elem, {
        size: 'small',
        jackColor: '#eC0000',
        color: '#800000',
        secondaryColor: '#c2c2c2',
        jackSecondaryColor: '#ffffff'
    });

    ///////////////// funciones de respuesta del signalr ////////////////////////////
    if (biochkHub != undefined) {

        biochkHub.client.urlFrontResponse = function () {
            //init url response
        }

        biochkHub.client.eraseBiometricsResponse = function () {
            //biochkHub.server.urlFront(window.location.href);
        }

        biochkHub.client.devicesSuccess = function () {
            //Se remplaza por funcionalidad original en onDevicesSuccess
            onDevicesSuccess();
        };

        biochkHub.client.isSuperUser = function () {
            bcstorage.issuper = true;
        }

        biochkHub.client.obtenerVersionDespliegue = function (respuesta) {
            obtenerVersionDespliegueExito = true;
        }

        biochkHub.client.biocheckVersionInstalador = function (response) {
            bcstorage.versionInstalador = response;
            $(".versionInstalador").text(response);
            //biochkHub.server.setConfigData();
        };

        biochkHub.client.biocheckEjecutaBat = function (response) {
            VerificarEscanerDocumentos();

        }

        biochkHub.client.failToken = function () {
            $scope.modalerrormensaje("Ocurri\u00F3 un error en la validaci\u00F3n de token.", "Salir", $scope.errorToken);
        }

        biochkHub.client.finalDate = function (hora, fecha, trasaction) {
            $scope.onFinalizarFlujo(hora, fecha, trasaction);
        }

        biochkHub.client.guid = function (guidHub) {
            guid = guidHub;
        };

        biochkHub.client.fail = function (code, message) {
            if (winPros) winPros.close();
            if (parseInt(code) == 310) {
                $scope.modalerrormensaje2("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>", "Repetir", $scope.error, $scope.cancelarinfo);
            } else if (parseInt(code) == 320)
                $scope.modalerrormensaje2("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/lector_conexion.png'></div>", "Repetir", $scope.error, $scope.cancelarinfo);
            else if (parseInt(code) == 330)
                $scope.modalerrormensaje2("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Repetir", repetir, $scope.cancelarinfo);
            else if (parseInt(code) >= 100 && parseInt(code) < 200)
                $scope.modalerrormensaje("Error inesperado en la lectura de licencias. C\u00F3digo: " + parseInt(code), "Salir", $scope.errorlicencias);
            else if (parseInt(code) === 331)
                $scope.modalerrormensaje("Servicio de escaneo de documentos no pudo ser iniciado.", "Salir", $scope.errorServiciosEscaner);
            else if (parseInt(code) === 332)
                $scope.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", $scope.errorServiciosEscaner);
            else if (parseInt(code) === 333) {
                //Si hay intentos, verifica el estatus del escaner
                if (intentosReiniciarEscaner < intentosResetEscanerDoc) {
                    //Incrementa los intentos en 1
                    intentosReiniciarEscaner++;
                    esReintentoEscaner = true;
                    $scope.modalerrormensaje2("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Repetir", $scope.error, $scope.cancelarinfo);
                }
                else {//Si no hay intentos, notifica y termina flujo
                    $scope.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", $scope.errorServiciosEscaner);
                }
            }
            else if (parseInt(code) === 350)
                $scope.modalerrormensaje(message, "Salir", $scope.errorServiciosEscaner);
        };

        biochkHub.client.setBucAnonimizada = function (bucAnonimizada) {
            bcstorage.bucAnonimizada = bucAnonimizada;
        }; //Obtenemos la buc anonimizada del cliente

        biochkHub.client.successToken = function (response) {
            try { bcstorage.tokenBase64 = response.Datos.stokenValidatorResponse.pAdicional; } catch (errorTokenBase64) { bcstorage.tokenBase64 = ""; }
            var code = response.CodigoEstatus;
            switch (code) {
                case 1:
                    bcstorage.biometricId = response.biometricId;
                    if (bcstorage.biometricId != null && bcstorage.biometricId != '' && bcstorage.biometricId != undefined) {
                        console.info('pycaso envio biometricID: ' + bcstorage.biometricId);
                    }
                    biochkHub.server.ejecutaBat();
                    break;
                case 2:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(biocheck.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones), "Salir", $scope.errorToken, response.CodigoError);
                    break;
                case 3:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(response.Mensaje, "Salir", $scope.errorToken, response.CodigoError);
                    break;
                case 4:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(response.Mensaje, "Salir", $scope.errorToken, response.CodigoError);
                    break;
                default:
                    $scope.modalerrormensaje("Ocurri\u00F3 un error en la validaci\u00F3n de token.", "Salir", $scope.errorToken);
            }
        }

        // Consulta a la PE68
        biochkHub.client.pE68GuardarRespuesta = function (response) {
            var code = response.CodigoEstatus;
            var errorcustom = false;

            //Se pone el codigo de estatus de la peticion REST independientemente del codigo de estatus de manejo interno
            var codigoEstatusRespuesta = "";
            if ((response.Datos != null && response.Datos != undefined) && (response.Datos.status != null && response.Datos.status != undefined)) {
                codigoEstatusRespuesta = response.Datos.status.statusCode;
            }
            else {
                codigoEstatusRespuesta = response.Mensaje
            }

            switch (code) {
                case 1:
                    if (response.Datos.status.statusCode == 0 && response.Datos.partyRec.partyInfo.personPartyInfo != null) {
                        var cData = response.Datos.partyRec.partyInfo.personPartyInfo;
                        bcstorage.apicNombre = cData.personName.givenName || '';
                        bcstorage.apicApellidoP = cData.personName.paternalName || '';
                        bcstorage.apicApellidoM = cData.personName.maternalName || '';
                        bcstorage.nombreCliente = bcstorage.apicNombre + " " + bcstorage.apicApellidoP + " " + bcstorage.apicApellidoM;
                        $scope.NombreCli = bcstorage.nombreCliente;
                        $("#nombreCliente").text("Cliente: " + bcstorage.nombreCliente);
                        $("#NombreClienteINE").html(bcstorage.nombreCliente);
                        $scope.tipoCliente = $scope.NombreCli;
                        if (cData.birthDt) {
                            if (cData.birthDt != null && cData.birthDt != "") {
                                if (typeof cData.birthDt != undefined) {
                                    var btDate = cData.birthDt.split("-");
                                    bcstorage.apicDia = btDate[2];
                                    bcstorage.apicMes = btDate[1];
                                    bcstorage.apicAno = btDate[0];
                                }
                            }
                        }
                        bcstorage.apicSexo = cData.gender == "MASCULINO" ? "H" : "M";
                        //bcstorage.apicNac = cData.birthPlace == "MEXICO";
                        //biochkHub.server.oDB6ConsultarCorreo();
                    }
                    else if (response.Datos.status.statusCode == 100) {
                        biocheck.modalerrormensaje("Ocurri\u00F3 un error en la consulta del cliente.", "Salir", function () {
                            $scope.errorConstEmple();
                        });
                    }
                    else {
                        /*Si el estatus de la respuesta que devuelve la API es fallido,
                        muestra mensaje y termina el flujo.*/
                        bcstorage.codigoflujo = "EPE6801";
                        var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                        biocheck.modalerrormensaje(msjError, "Salir", function () { biochkHub.server.getFinalDate() });
                    }
                    break;
                case 2:
                    bcstorage.codigoflujo = response.CodigoError;
                    var flagbuc = false;
                    $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
                        if (value.indexOf("customer does not exist") != -1)
                            flagbuc = true;
                    });
                    if (flagbuc) {
                        var msjFinal = "";
                        $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
                            msjFinal += key;
                        });
                        $scope.modalerrormensaje(msjFinal, "Salir", $scope.errorGeneral, response.CodigoError);
                    }
                    else
                        $scope.modalerrormensaje(biocheck.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones), "Salir", $scope.errorGeneral, response.CodigoError);
                    break;
                case 3:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;
                case 4:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;
                default:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;

            }
        }


        biochkHub.on("oDB6ConsultarCorreoRespuesta", function (resultado) {
            onODB6ConsultarCorreoRespuesta(resultado);
            if (winPros) winPros.close();
            CloseAllJConfirm();

        });

        biochkHub.client.configuracionRespuesta = function (respuesta) {
            if (respuestaCargada === true) {
                return;
            }
            respuestaCargada = true;
            var versionSistema = '';
            if (respuesta.VersionSistema != null && respuesta.VersionSistema != undefined && respuesta.VersionSistema != '') {
                versionSistema = respuesta.VersionSistema;
            }
            bcstorage.OmitirVigenciaIne = false;
            if (respuesta.OmitirVigenciaIne != null && respuesta.OmitirVigenciaIne != undefined && respuesta.OmitirVigenciaIne != '') {
                bcstorage.OmitirVigenciaIne = respuesta.OmitirVigenciaIne;
                bcstorage.EstadosVigenciaIne = respuesta.EstadosVigenciaIne;
            }

            //Si el BWS no es capaz de entregar la version del sistema o si la entrega y esta es diferente a la declarada en el front, redirecciona.
            if (versionSistema == '' || versionSistema != bcstorage.versionSistema) {
                redireccionar();
            }
            else {
                if (bcstorage.successToken == undefined || bcstorage.successToken == false) {
                    VerificarToken();
                } else {
                    biochkHub.server.ejecutaBat();
                }
            }
        }

        biochkHub.client.failConfig = function () {
            if (winPros) winPros.close();
            $scope.modalerrormensaje("Ocurri\u00F3 un error en la consulta de configuraci\u00F3n.", "Salir", $scope.errorConfig);
        }

        //Funciones reset escaner

        biochkHub.client.respuestaProcesador = function (respuesta) {
            console.log("recibe respuesta procesador");
            switch (respuesta.Id) {
                case 'VerificarEstatusEscanerDoc':
                    if (respuesta.Respuesta != undefined && respuesta.Respuesta != null && respuesta.Respuesta != '') {
                        //Verificar si el escaner esta conectado y online
                        ActivarModoManualEscaner();

                    }
                    break;
                case 'VerificarEscanerConectadoOnline':
                    if (respuesta.Respuesta != undefined && respuesta.Respuesta != null && respuesta.Respuesta != '') {
                        //Poner el flujo que se quiere ejecutar en la respuesta
                        ActivarModoManualEscaner();
                    }
                    break;
                case 'ActivarModoManualEscaner':

                    biochkHub.server.checkIfCameraIsConected().done(function (result) {
                        if (result) {
                            onDevicesSuccess();
                        } else {
                            CameraNotFound(310);
                        }
                    });
                    break;
                default:
                    break;
            }


        }

        biochkHub.client.biocheckEjecutaBat = function (response) {
            VerificarEscanerDocumentos();

        }
    }

    ///////////////// eventos ////////////////////////////

    elem.onchange = function () {
        //se ejecuta al activar o desactivar el switch del enviar email
        $scope.mostrarCorreoElectronico = !$scope.mostrarCorreoElectronico;
        $scope.$applyAsync();
    };

    $scope.emailChange = function () {
        $("#correoElectronico").blur();
        $("#correo").blur();
    };

    //////////////// funciones en scope //////////////////

    $scope.getParameterByName = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    $scope.cancelar = function () {
        biocheck.cancelar(function () {
            bcstorage.proceso = true;
            bcstorage.codigoflujo = "CA000";
            biochkHub.server.getFinalDate();
        });
    };

    $scope.iniciar = function () {
        if ($scope.mostrarCorreoElectronico === true) {
            if (emailValido()) {
                $scope.msjerror = '';
                var correoElectronico = "";
                if ($scope.dominio === 'Otro') {
                    correoElectronico = $scope.email;
                } else {
                    if ($scope.email != null && $scope.email != undefined && $scope.email != '') {
                        correoElectronico = $scope.email + $scope.dominio;
                    } else {
                        correoElectronico = '';
                    }
                }
                // MXSLBIOM-1631: Enviar el aviso de privacidad al correo electronico del cliente en el flujo de no enrolados escritorio
                biochkHub.server.notificacionEmail(correoElectronico, 'AvisoDePrivacidad');
                pasarSiguientePagina();
            } else {
                $scope.msjerror = 'Correo electronico erroneo';
            }
        } else {
            pasarSiguientePagina();
        }
        $scope.$applyAsync();
    };

    $scope.errorToken = function () {
        CloseAllJConfirm();
        bcstorage.proceso = false;
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        //bcstorage.codigoflujo = "ETO01";
        biochkHub.server.getFinalDate();
    };

    $scope.onFinalizarFlujo = function (hora, fecha, trasaction) {
        if (winPros) winPros.close();
        CloseAllJConfirm();
        bcstorage.fechapros = hora;
        bcstorage.horapros = fecha;
        bcstorage.foliopros = trasaction;
        if (biocheck.codigoError(bcstorage.codigoflujo) != '0')
            bcstorage.mensajeflujo = biocheck.codigoError(bcstorage.codigoflujo);
        biocheck.onStopSignalR();
        $(location).attr('href', '#!/finalizar');
    };

    $scope.error = function () {
        winPros = $scope.procesando("Cargando datos");
        winPros.open();
        //biochkHub.server.devicesConnected(guid);
        //biochkHub.server.getFingerLicences(guid);
        $scope.cont = 0;
    };

    $scope.cancelarinfo = function () {
        bcstorage.proceso = true;
        bcstorage.codigoflujo = "CA000";
        biochkHub.server.getFinalDate();
    }

    $scope.errorlicencias = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "ELB00";
        biochkHub.server.getFinalDate();
    };

    //Funcion para error en los servicios del escaner de documentos
    $scope.errorServiciosEscaner = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "ELB01";
        biochkHub.server.getFinalDate();
    };

    /////////////// funciones ////////////////

    function VerificarToken() {
        if ($scope.isnotwhitelist == true) {
            var testtoken = $scope.getParameterByName('testtoken');
            if (bcstorage.token)
                if (bcstorage.token != "" && bcstorage.token != null) {
                    bcstorage.successToken = true;
                    biochkHub.server.verifyToken(bcstorage.token);
                }
                else {
                    if (testtoken == "false") {
                        bcstorage.successToken = true;
                        biochkHub.server.verifyToken(bcstorage.token);
                    }
                    else {
                        bcstorage.proceso = false;
                        bcstorage.codigoflujo = "ETO06";
                        biochkHub.server.getFinalDate();
                    }
                }
            else {
                if (testtoken == "false") {
                    bcstorage.successToken = true;
                    biochkHub.server.verifyToken(bcstorage.token);
                }
                else {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "ETO06";
                    biochkHub.server.getFinalDate();
                }
            }
        }
    }

    function onDevicesSuccess() {
        biochkHub.server.transactionID();
        biochkHub.server.pE68Consultar();
    }

    biochkHub.client.setRedirectUrl = function (resultUrl) {
        setTimeout(function () {
            if (winPros)
                winPros.close(); //Se debe cerrar el modal
            biocheck.onStopSignalR(); //Se debe cerrar la comunici�n
            var urlParams = "Ejecutivo";
            var hashSymbol = true;
            var targetUrl = resultUrl + (hashSymbol == true ? "/#!/" : "/") + urlParams;
            window.location.replace(targetUrl);
        }, 3000);
    };//Redirecciona a otra version

    function redireccionar() {
        biochkHub.server.getFrontUrl("verify", true);
    }

    function VerificarEscanerDocumentos() {
        ControladorFunciones("VerificarEstatusEscanerDoc", {});
    }

    function ActivarModoManualEscaner() {
        ControladorFunciones("ActivarModoManualEscaner", {});
    }

    function repetir() {
        winPros = biocheck.procesando("Captura identificacion");
        winPros.open();
        VerificarEscanerDocumentos();
    }

    function ControladorFunciones(id, parametrosEntrada) {
        var funcion = {
            Id: id,
            ParametrosEntrada: parametrosEntrada
        };

        biochkHub.server.procesador(funcion);
    }

    function validacionEmail(email) {
        var estructuraValida = true;
        var regex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/igm;
        if (email === '') {
            $scope.msjerror = '';
            estructuraValida = true;
            //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
            $('#emailform').css('border', 'solid 1px #ced4da');
        } else {
            if (!email.match(regex)) {
                $scope.msjerror = 'El correo electr\u00F3nico es inv\u00E1lido';
                setTimeout(function () {
                    $('#email__campoTexto').css('border', '1px solid #ec0000');
                    $('#msj-error').css('color', '#ec0000');
                }, 100);
                estructuraValida = false;
            } else {
                $scope.msjerror = '';
                estructuraValida = true;
                //$('#emailform').css('border', 'solid 1px rgb(27, 179, 188)');
                $('#email__campoTexto').css('border', 'solid 1px #ced4da');
            }
        }
        return estructuraValida;
    }

    function emailValido() {
        var correoElectronico = ''; //variable auxiliar
        var emailok = true;
        if ($scope.mostrarCorreoElectronico) {
            if ($scope.email.length !== 0) {
                if ($scope.dominio === 'Otro') {
                    correoElectronico = $scope.email;
                } else {
                    correoElectronico = $scope.email.concat($scope.dominio);
                } //acomodamos el correo electronico para poder trabajarlo
                emailok = validacionEmail(correoElectronico);
            } else {
                correoElectronico = '';
                emailok = false;
            }
        }
        return emailok;
    }

    function onODB6ConsultarCorreoRespuesta(resultado) {
        if (resultado.CodigoEstatus == null || resultado.Datos == null ||
            resultado.Datos.status == null || resultado.Datos.status.statusCode == null ||
            typeof resultado.CodigoEstatus == 'undefined' || typeof resultado.Datos == 'undefined' ||
            typeof resultado.Datos.status == 'undefined' || typeof resultado.Datos.status.statusCode == 'undefined') {
            //Significa que ocurrio un problema en el WSB y no logramos consultar el correo
            $scope.email = '';
            $scope.dominio = "@gmail.com";
        }

        if (resultado.CodigoEstatus === catEstatusRespuesta.Exito && resultado.Datos.status.statusCode == 0) {//Significa que si logramos obtener el correo guardado en 390
            var emailAddress = null;
            try {
                emailAddress = resultado.Datos.partyInqObjRec[0].contact.email.emailAddr;
            } catch (error) {
                emailAddress = null;
                try {
                    $.connection.biocheckHub.server.escribeLog("error", "PaaS [" + window.location.href + "] onODB6ConsultarCorreoRespuesta", error);
                } catch (tryError) {
                    // ignored
                }
            }
            if (emailAddress != undefined && emailAddress != null && emailAddress != "undefined" && emailAddress != "") {
                mostrarEmail(emailAddress);
            } else {
                $scope.email = '';
                $scope.dominio = "@gmail.com";
            }
        } else {
            //Significa que ocurrio un problema en el WSB y no logramos consultar el correo
            $scope.email = '';
            $scope.dominio = "@gmail.com";
        }
    }

    function mostrarEmail(email) {
        if (email) {
            var correoElectronico = email.split('@', 2);
            $scope.email = correoElectronico[0];
            // Se convierte a minusculas para hacer la comparacion, de lo contrario, si el correo viene en mayusculas, se pondra siempre Otro
            $scope.dominio = '@' + correoElectronico[1].toLowerCase();
            if ($scope.dominio !== '@gmail.com' && $scope.dominio !== '@yahoo.com' && $scope.dominio !== '@outlook.com' && $scope.dominio !== '@hotmail.com' && $scope.dominio !== '@yahoo.com.mx') {
                $scope.dominio = 'Otro';
                $scope.email = email;
            }
        } else {
            $scope.email = '';
            $scope.dominio = "@gmail.com";
        }
    }

    function initVistas() {
        DOM.totalPasos(4);
        DOM.cambiarPaso(1, "Inicio");
        DOM.mostrarSubheader();
    }

    function init() {
        initVistas();
    }

    // Cierra todas las instancias del plugin JConfirm activas
    function CloseAllJConfirm() {
        try {


            var instances = jconfirm.instances;
            instances.forEach(function (elemento, indice, array) {
                elemento.close();
            });
        } catch (e) {
            console.log(e);
        }
    }

    function pasarSiguientePagina() {
        biocheck.onStopSignalR();
        $(location).attr('href', '#!/NoEnrolado/facialIneRostroCaptura');
    }

    //init();

    function startSignalR() {

        biochkHub.server.eraseBiometrics();

        var urlpag = window.location.href;
        biochkHub.server.urlFront(urlpag);
        biochkHub.server.obtenerVersionDespliegue();
        biochkHub.server.getBiocheckVersion(bcstorage.versionBiocheck, bcstorage.versionSistema);
        biochkHub.server.setConfigData();
        $(".versionBiocheck").text(bcstorage.versionBiocheck);
    }

    biocheck.onStartSignalR(startSignalR);

    $.connection.hub.reconnecting(function () {
        //No es necesario una funcionalidad aqu�
    });

    // reconnected the connection.
    $.connection.hub.reconnected(function () {
        //No es necesario una funcionalidad aqu�
    });

    $.connection.hub.disconnected(function () {
        //No es necesario una funcionalidad aqu�
    });

    $scope.cancelar = function () {
        biocheck.cancelar(function () {
            $scope.error("CA000", "Proceso cancelado")
        });
    };

    $scope.error = function (codigoError) {
        bcstorage.codigoflujo = codigoError;
        codigoError === "CA000" ? bcstorage.proceso = true : bcstorage.proceso = false;
        biochkHub.server.getFinalDate();
    };

    if ($scope.dominio == "") {
        $scope.dominio = "@gmail.com";
        $scope.$applyAsync();
    }
});
