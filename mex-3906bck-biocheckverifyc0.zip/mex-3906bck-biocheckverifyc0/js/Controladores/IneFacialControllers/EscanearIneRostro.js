var app = angular.module("myApp");
app.controller("EscanearIneRostroController", function ($scope, biocheck, bcstorage, DOM) {
    //checa si el servicio esta activo
    biocheck.checkService();
    //Declaracion de variables
    /*BIOCHECKHUB*/
    var winPros = null;
    $.connection.hub.url = bcstorage.hubUrl;
    var biochkHub = $.connection.biocheckHub;

    var signalr = $.connection.biocheckHub;

    //Variables reset escáner
    var intentosReiniciarEscaner = 0;
    var intentosResetEscanerDoc = 3;
    var esReintentoEscaner = false;
    //Variables reset escáner

    //*BIOCHECKHUB*/
    $scope.scan = true; //esta variable es para saber si el boton escaneara o ira a la siguiente pagina
    bcstorage.isCIC = false;
    var btnEscanear = document.getElementById('btnEscan');
    var textoInstruccion = document.getElementById('instruccionife');

    // ADD ESCANER MANUAL
    var modalSideB = {
        //init modalsideb
    };
    modalSideB.onOpen = null;
    modalSideB.onClose = null;
    function crearModal1() {
        modalSideB = $.confirm({
            title: '',
            content: '<style> .jconfirm-buttons{ display:inline!important; } .jconfirm-title-c{ display:none; } .jconfirm-content-pane{ min-height:180px!important; margin-bottom:0!important}</style>' + '<div class="textoErrorModal">Voltear documento.</div>',
            closeIcon: false,
            useBootstrap: false,
            boxWidth: '40%',
            lazyOpen: true,
            alignMiddle: true,
            typeAnimated: true,
            draggable: false,
            buttons: {
                Sig: {
                    text: "Escanear",
                    btnClass: 'boton_Positivo btn-ScanB',
                    action: function () {
                        scanSideB();
                    }
                }
            }
        });
        modalSideB.onOpen = function () {
            //init modalsideb
        };
        modalSideB.onDestroy = function () {
            crearModal1();
        };
    }

    function scanSideB() {
        signalr.server.scanDocumentManual(1);
        $("#instrucciones").modal("show")
        var resp = {
            Code: 7,
            Message: "Escaneando documento."
        };
        onRespuestaInstruccion(resp);
    };
    //

    var respuestaNacional =
        '<div class="std-centrarelem columna">\n' +
        '<div class="separar"><img src="img/error/14.png" width="350px"></div>\n' +
        '<div class="font20 negrita">Identificaci&oacute;n incorrecta</div>\n' +
        '<div class="font16 separar" style="font-weight: normal;">Para continuar con el registro favor de proporcionar una credencial para votar.</div>\n' +
        '</div>';

    var errorVigencia = '<div class="std-centrarelem columna">' +
        '<div class="separar2">' +
        '<img src="img/error/14.png" style="width: 350px">' +
        '</div>' +
        '</div>' +
        '<div class="std-centrarelem columna">' +
        '<div class="text-center std-tituloFont font16">' +
        'Indica al cliente que la identificación no está vigente' +
        '</div>' +
        '<div class="font14" style="font-weight: normal;">' +
        'que es importante que actualice su identificación</br>' +
        'para realizar cualquier trámite con el banco.</br></div></div>';

    $scope.respuestaInstruccion = '';
    $scope.regresoRespuesta = false;

    //Callback de lo que hara el modal al cerrar el modal
    $('#instrucciones').on('hidden.bs.modal', function (e) {
        $scope.onCerrandoModalErrorSinEscaner();
    });
    //Callback de lo que hara el modal al abrir el modal
    $("#instrucciones").on('shown.bs.modal', function () {
        onAbrirModalErrorSinEscaner();
    });

    $scope.inicializarVista = function () {
        //aparecemos el header y decimos en que paso estamos
        //DOM.totalPasos(4);
        DOM.cambiarPaso(3, "Escanear identificación");
        DOM.mostrarSubheader();
        //creamos los tooltip
        jQuery('.bottom').tipso({
            position: 'bottom-right',
            background: '#deedf2',
            color: '#000',
            useTitle: false,
            tooltipHover: true,
            width: 380
        });
        $scope.textoBtnScanear(true);

    };//funcion inicial para la vista    
    $scope.error = function (codigoError) {
        bcstorage.codigoflujo = codigoError;
        codigoError === "CA000" ? bcstorage.proceso = true : bcstorage.proceso = false;
        signalr.server.getFinalDate();
    };//Se utilizara para terminar asignar el codigo de error o cancelacion y llamara a la funcion de pasar a "finalizar"
    $scope.textoBtnScanear = function (valor) {
        if (valor) {
            $scope.scan = true;
            btnEscanear.innerHTML = "Escanear";
        } else {

            $scope.scan = false;
            btnEscanear.innerHTML = "Continuar";

        }
    };//Cambia el texto del boton a "escanear" o "continuar" ademas de que decide el flujo

    function limpiarVigencia(fecha) {
        var fechas = [];
        if (!fecha) {
            return '';
        } else {
            fechas = fecha.split("-");
            return fechas[fechas.length - 1];
        }
    }
    function guardarDatosEscaneados(responseEscaner) {
        var imagenFrente = false;
        var imagenAtras = false;
        $.each(responseEscaner.Values, function (i, v) {//Esto es para la clave de lector de INE
            if (v.Name == "CIC") {
                bcstorage.isCIC = true; //Bandera de que la INE tiene CIC
                bcstorage.cic = v.Value;
            }
        });
        $.each(responseEscaner.Values, function (i, v) {
            if (v.Name == "FrontImage") {
                var frente = $("#frente");
                if (frente.length > 0) {
                    frente.attr("src", "data:image/png;base64," + v.Value);
                    //frente.removeClass("imagenOpaca");
                    frente.css('opacity', '1');
                    imagenFrente = true;
                }
            }
            if (v.Name == "BackImage") {
                var atras = $("#atras");
                if (atras.length > 0) {
                    atras.attr("src", "data:image/png;base64," + v.Value);
                    atras.css('opacity', '1');
                    imagenAtras = true;
                }
            }
            if (v.Name == "VIZ Given Name") {
                bcstorage.nombre = v.Value;
            }//Nombre
            if (v.Name == "VIZ Surname") {
                bcstorage.apellidos = v.Value;
            }
            if (v.Name == "VIZ Father's Surname") {
                bcstorage.apellidoP = v.Value;
            }
            if (v.Name == "VIZ Mother's Surname") {
                bcstorage.apellidoM = v.Value;
            }
            if (v.Name == "Birth Date Day") {
                bcstorage.dia = v.Value;
            }//BirthDate
            if (v.Name == "Birth Date M") {
                bcstorage.mes = v.Value;
            }
            if (v.Name == "Birth Date Year") {
                bcstorage.ano = v.Value;
            }
            if (v.Name == "BirthCode") {
                bcstorage.entidadNacimiento = v.Value;
            }
            if (v.Name == "Type") {
                bcstorage.type = v.Value;
            }
            if (v.Name == "OCR") {
                bcstorage.ocr = v.Value;
            }
            if (v.Name == "Sex") {
                bcstorage.sexo = v.Value;
            }
            if (v.Name == "VIZ Registration Number") {
                bcstorage.claveElector = v.Value;
            }
            if (v.Name == "Verification Number") {
                bcstorage.codigoEmision = v.Value;
            }
            if (v.Name == "ExisteVigencia") {
                if (v.Value == 'true') {
                    bcstorage.existenciaVigencia = true;
                } else {
                    bcstorage.existenciaVigencia = false;
                }
            }//Existencia Vigencia
            if (v.Name == "VIZ Expiration Date") {
                bcstorage.vigencia = limpiarVigencia(v.Value);
            }//vigencia
            if (v.Name == "CURP") {
                bcstorage.curp = v.Value;
            }
            if (v.Name == "Nationality Name") {
                bcstorage.nacionalidad = v.Value;
            }
            if (v.Name == "CP") {
                bcstorage.CP = v.Value;
            }
            if (v.Name == "Colonia") {
                bcstorage.Colonia = v.Value;
            }
            if (v.Name == "Edo") {
                bcstorage.EDO = v.Value;
            }
            if (v.Name == "Calle") {
                bcstorage.Calle = v.Value;
            }
            if (v.Name == "DelMun") {
                bcstorage.DelMun = v.Value;
            }
            if (v.Name == "VIZ Address") {
                bcstorage.direccionCalle = '';
                bcstorage.direccionColonia = '';
                bcstorage.direccionMunicipio = '';
                var dir = v.Value.split('<');
                if (dir.length >= 1)
                    bcstorage.direccionCalle = dir[0];
                if (dir.length >= 2)
                    bcstorage.direccionColonia = dir[1];
                if (dir.length >= 3)
                    bcstorage.direccionMunicipio = dir[2];
            }
            if (v.Name == "ClaveEntidad") {
                bcstorage.ClaveEntidad = v.Value;
            }

            /*  if (v.Name == "Issue Date") {
                  var anioRegistro = v.Value.split("/")
                  if (anioRegistro.length >= 3)
                      bcstorage.anioRegistro = dir[2];
              }*/
            if (v.Name == "VIZ Issue Year and Expiration Year") {
                var anioEmision = v.Value.split("-");
                if (anioEmision.length >= 2)
                    bcstorage.anioEmision = anioEmision[0];

            }
            if (v.Name == "Registration Year and Verification Number") {
                var anioRegistro = v.Value.split(" ");
                if (anioRegistro.length >= 2)
                    bcstorage.anioRegistro = anioRegistro[0];

            }
        });
        if (imagenFrente && imagenAtras) {
            return true;
        } else {
            return false;
        }  //Revisamos si se escanearon correctamente los dos lados
    }
    function validarVigencia(existeVigencia, fecha) {
        var fechaDeHoy = new Date();
        var anio = fechaDeHoy.getFullYear();
        if (existeVigencia) {
            if (anio <= parseInt(fecha)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    //funciones de respuesta
    function onErrorEscaner(responseEscaner) {
        $scope.respuestaInstruccion = responseEscaner;
        if ($("#instrucciones").modal("show")) {
            $("#instrucciones").modal("hide");
        } else {
            biocheck.modalerrormensaje(responseEscaner, "OK", "");
            $scope.textoBtnScanear(true);
        }
    }
    function onRespuestaEscaner(responseEscaner) {
        $scope.onCerrandoModalErrorSinEscaner = function () {
            //init cerrar modal;
        };
        if ($("#instrucciones").modal("show")) {
            $("#instrucciones").modal("hide");
            //setTimeout(function(){$(location).attr('href', '#!/Ejecutivo/ocrdeife')},3000);
        }
        $.connection.biocheckHub.server.escribeLog("warning", "CaaS [" + window.location.href + "]", responseEscaner.Message);
        if (responseEscaner.Message == 'Side A') {
            crearModal1();
            modalSideB.open();
            return;
        }
        if (responseEscaner.Success) {
            //if (modalSideB.isOpen()) {
            //    modalSideB.close();
            //}
            //checamos si es valido el documento escaneado
            if (responseEscaner.valid) {
                if (guardarDatosEscaneados(responseEscaner)) {
                    if (bcstorage.existenciaVigencia) {
                        /* !!! MXSLBIOM-2448 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2019 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. Se deberá modificar la bandera no eliminarla, es decir, cuando termine la prórroga del INE se puede volver hacer las validaciones de las vigencias actuales. 
                         * !!! MXBIOC-193 Yo como Cliente requiero que mi credencial de elector que tiene vigencia de 2020 pueda hacer mi enrolamiento sin que se rechace por esta vigencia, aceptándola hasta junio 2021. ====================================== */
                        var anioVigencia = parseInt((bcstorage.vigencia) ? bcstorage.vigencia : 0);
                        var listEstadosVigencia = bcstorage.EstadosVigenciaIne !== undefined ? bcstorage.EstadosVigenciaIne.split(',') : "";
                        var ExisteEstado = listEstadosVigencia !== "" ? listEstadosVigencia.find(function (value, index) { return value == bcstorage.ClaveEntidad; }) : false;
                        var FechaAplicaVigencia = bcstorage.FechaVigenciaProrroga !== undefined ? (bcstorage.FechaVigenciaProrroga !== "" ? new Date(bcstorage.FechaVigenciaProrroga) : new Date("01/01/1990")) : new Date("01/01/1990")
                        var fechaDeHoy = new Date();
                        var anio = fechaDeHoy.getFullYear(); //año valido vigente
                        var FechaTerminoProrroga = true;
                        if (anioVigencia < anio && FechaAplicaVigencia < fechaDeHoy)
                            FechaTerminoProrroga = false
                        var reglaOmitirVigencia = bcstorage.OmitirVigenciaIne === true && FechaTerminoProrroga && ExisteEstado != undefined;
                        if (reglaOmitirVigencia === true || validarVigencia(bcstorage.existenciaVigencia, bcstorage.vigencia)) {
                            $scope.textoBtnScanear(false);
                        } else {
                            $scope.textoBtnScanear(true);
                            biocheck.modalerrormensaje(errorVigencia, "Finalizar", function () { $scope.error("EOB09") });
                        }
                    } else {
                        biocheck.modalerrormensaje(errorVigencia, 'Finalizar', function () { $scope.error('EBC00') });
                    }
                } else {
                    $("#frente").attr("src", "img/INE(Front).png");
                    $("#atras").attr("src", "img/INE(Back).png");
                    $scope.textoBtnScanear(true);
                    biocheck.modalerrormensaje("Debe escanear ambos lados de la identificación", "Repetir", function () {
                        //init function
                    });
                }

            } else {
                $scope.textoBtnScanear(true);
                if (responseEscaner.TypeModal == 2) {
                    var documentoCaducado = false;
                    var vigencia = '';
                    $.each(responseEscaner.Values, function (i, v) {//Esto es para la clave de lector de INE
                        if (v.Name == "VIZ Expiration Date") {
                            vigencia = v.Value;
                            var fechaHoy = new Date();
                            //fecha de hoy
                            var dd = fechaHoy.getDate();
                            var mm = fechaHoy.getMonth() + 1;
                            var yyyy = fechaHoy.getFullYear();
                            var date_regex = /^(0[1-9]|1\d|2\d|3[01])\-(0[1-9]|1[0-2])\-(19\d{2}|2\d{3})$/;//Esta epresion regular revisa que la vigencia tenga el formato correcto

                            //aqui evaluamos que la vigencia sea valida
                            if (date_regex.test(vigencia)) {
                                var fecha = v.Value.split('-');
                                var anioEscan = parseInt(fecha[2]);
                                var mesEscan = parseInt(fecha[1]) - 1;
                                var diaEscan = parseInt(fecha[0]);
                                var vigenciafecha = new Date(anioEscan, mesEscan, diaEscan);
                                if (vigenciafecha < fechaHoy)
                                    documentoCaducado = true;
                            }
                        }//vigencia
                    });
                    if (documentoCaducado) {
                        biocheck.modalerrormensaje(errorVigencia, "Finalizar", function () { $scope.error("EOB09"); });
                    } else {
                        biocheck.modalerrormensaje(responseEscaner.Message, "Finalizar", function () { $scope.error("EOB09"); });
                    }

                } else if (responseEscaner.TypeModal == 3) {
                    if (responseEscaner.Message == 'DocumentoErroneo')
                        biocheck.modalerrormensaje(respuestaNacional, "Repetir", "");
                    else
                        biocheck.modalerrormensaje(responseEscaner.Message, "Repetir", "");
                }
                else {
                    biocheck.modalerrormensaje(respuestaNacional, "Repetir", "");
                }
            }
        } else {
            $scope.textoBtnScanear(true);
            if (responseEscaner.ScanBothSides) {
                biocheck.modalerrormensaje(respuestaNacional, "Repetir", "");
            }
            else if (responseEscaner.Message === 'Identificación no detectada.') {
                biocheck.modalerrormensaje('Por favor vuelve a escanear la identificación', "Repetir", "");
            } else {
                biocheck.modalerrormensaje(responseEscaner.Message, "Repetir", "");
            }
        }
    }

    function onRespuestaInstruccion(responseEscaner) {
        $scope.respuestaInstruccion = responseEscaner;
        switch (responseEscaner.Code) {
            case 5:
            case 6:
                $scope.errorEscaner = true;
                if ($("#instrucciones").modal("show")) {
                    $("#instrucciones").modal("hide");
                    //setTimeout(function(){$(location).attr('href', '#!/Ejecutivo/ocrdeife')},3000);
                }
                break;
            case 1:
            case 7:
                //$('#instrucciones').text('Escaneando documento.');
                textoInstruccion.innerHTML = "Escaneando documento.";
                break;
            case 4:
                $scope.errorEscaner = false;
                if ($("#instrucciones").modal("show")) {
                    $("#instrucciones").modal("hide");
                    //setTimeout(function(){$(location).attr('href', '#!/Ejecutivo/ocrdeife')},3000);
                }
                break;
            default:
                textoInstruccion.innerHTML = responseEscaner.Message;
                //$('#instrucciones').text(responseEscaner.Message);
                break;
        }
        //if (responseEscaner.Code === 6) {
        //    $("#instrucciones").modal("hide");
        //    msgErrorEscaner = "<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>";
        //    biocheck.modalerrormensaje(msgErrorEscaner, "Repetir", "");
        //    //setTimeout(function(){$(location).attr('href', '#!/VentanillaINE/finalizar')},2000);
        //} else if (responseEscaner.Code === 1) {
        //    textoInstruccion.innerHTML = "Detectando documento.";
        //} else {
        //    textoInstruccion.innerHTML = responseEscaner.Message;
        //}

    }

    function onFinalDato(hora, fecha, trasaction) {
        bcstorage.fechapros = fecha;
        bcstorage.horapros = hora;
        bcstorage.foliopros = trasaction;
        biocheck.onStopSignalR();
        $(location).attr('href', '#!/finalizar');
    }
    $scope.onCerrandoModalErrorSinEscaner = function onCerrandoModalErrorSinEscaner() {
        var msgErrorEscaner = $scope.respuestaInstruccion.Message;
        if ($scope.respuestaInstruccion.Message === undefined || typeof $scope.respuestaInstruccion.Message === 'undefined' || /(esc(a|á)ner de documentos.*conectado)|(conexiones.*esc(a|á)ner de documentos)/i.test($scope.respuestaInstruccion.Message)) {
            msgErrorEscaner = "<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>";
        }

        biocheck.modalerrormensaje(msgErrorEscaner, "Repetir", "");

        $scope.textoBtnScanear(true);
    }
    function onAbrirModalErrorSinEscaner() {
        signalr.server.scanDocument(1);
    }

    //------------------------------------------------------------------------------------------------------------//
    //INICIA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
    //INICIA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
    var cancelarinfo = function () {
        bcstorage.proceso = true;
        bcstorage.codigoflujo = "CA000";
        signalr.server.getFinalDate();
    };

    signalr.client.respuestaProcesador = function (respuesta) {
        switch (respuesta.Id) {
            case 'VerificarEstatusEscanerDoc':
                if (respuesta.Respuesta != undefined && respuesta.Respuesta != null && respuesta.Respuesta != '') {
                    //Verificar si el escaner está conectado y online
                    ActivarModoManualEscaner();
                }
                break;
            case 'VerificarEscanerConectadoOnline':
                if (respuesta.Respuesta != undefined && respuesta.Respuesta != null && respuesta.Respuesta != '') {
                    //Poner el flujo que se quiere ejecutar en la respuesta
                    ActivarModoManualEscaner();
                }
                break;
            case 'ActivarModoManualEscaner':
                if (winPros)
                    winPros.close(); //Se debe cerrar el modal
                // Se ejecuta función que indica que los dispositivos se chequearon con éxito
                break;
            default:
                break;
        }
    };

    signalr.client.fail = function (code, message) {
        if (winPros)
            winPros.close();

        // MXSLBIOM-1476: Una vez que se llega a la parte de escaneo de documentos, se da click en el botón de Escanear, (el escáner sigue desconectado) entonces el sistema muestra ventana en blanco sin mensaje y al ver la consola muestra una variable no definida "Error".
        if (parseInt(code) == 330) {
            biocheck.modalerrormensaje2("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Repetir", VerificarEscanerDocumentos, cancelarinfo);
        }
        else if (parseInt(code) === 331)
            biocheck.modalerrormensaje("Servicio de escaneo de documentos no pudo ser iniciado.", "Salir", errorServiciosEscaner);
        else if (parseInt(code) === 332) {
            biocheck.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", errorServiciosEscaner);
        }
        else if (parseInt(code) === 333) {
            //Si hay intentos, verifica el estatus del escáner
            if (intentosReiniciarEscaner < intentosResetEscanerDoc) {
                //Incrementa los intentos en 1
                intentosReiniciarEscaner++;
                esReintentoEscaner = true;
                biocheck.modalerrormensaje2("Por favor asegúrate que el escáner de documentos esté conectado.", "Repetir", VerificarEscanerDocumentos, cancelarinfo);
            }
            else {//Si no hay intentos, notifica y termina flujo
                biocheck.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", errorServiciosEscaner);
            }
        }
        else if (parseInt(code) === 350)
            $scope.modalerrormensaje(message, "Salir", errorServiciosEscaner);
    };

    function VerificarEscanerDocumentos() {
        ControladorFunciones("VerificarEstatusEscanerDoc", {});
    }

    function VerificarEscanerConectadoOnline() {
        winPros = biocheck.procesando("Captura identificacion");
        winPros.open();
        ControladorFunciones("VerificarEscanerConectadoOnline", {});
    }

    function ActivarModoManualEscaner() {
        ControladorFunciones("ActivarModoManualEscaner", {});
    }

    function ControladorFunciones(id, parametrosEntrada) {
        var funcion = {
            Id: id,
            ParametrosEntrada: parametrosEntrada
        };

        signalr.server.procesador(funcion);
    }

    var errorServiciosEscaner = function () {
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "ELB01";
        signalr.server.getFinalDate();
    };//Función para error en los servicios del escaner de documentos
    //TERMINA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
    //TERMINA BLOQUE PARA VALIDACIÓN Y RESET DE ESCÁNER
    //------------------------------------------------------------------------------------------------------------//

    //funciones de respuesta al escanear
    signalr.client.failScan = function (response) {
        onErrorEscaner(response);
    };
    signalr.client.responseScan = function (response) {
        alert("escane");

    };
    signalr.on("responseScanIneFacial", function (response) {
        onRespuestaEscaner(response);

    });
    signalr.client.instructionScan = function (response) {
        onRespuestaInstruccion(response);
    };
    signalr.client.finalDate = function (hora, fecha, trasaction) {
        onFinalDato(hora, fecha, trasaction);
    };

    $scope.continuar = function () {
        if ($scope.scan) {
            $("#instrucciones").modal("show");
        } else {
            biocheck.onStopSignalR();
            $(location).attr('href', '#!/NoEnrolado/facialIneOcr');

        }
    };
    $scope.cancelar = function () {
        biocheck.cancelar(function () {
            $scope.error("CA000")
        });
    };

    $scope.inicializarVista();//inicializamos los cambios de la vista 

    $.connection.hub.reconnecting(function () {
        //No es necesario una funcionalidad aquí
    });//ejecuta funciones cuando el servicio se intenta reconectar
    $.connection.hub.reconnected(function () {
        //No es necesario una funcionalidad aquí
    });// Cuando se vuelve a conectar se ejecutan las instrucciones
    $.connection.hub.disconnected(function () {
        //No es necesario una funcionalidad aquí
    });// Se ejecuta cuando se desconecta el servicio
    biocheck.onStartSignalR(function () {
        //Se verifica el escáner, el estatus del assure ID y se comienza flujo de reseteo en caso de ser necesario
        //signalr.server.stopCamera();
        // signalr.server.stopCamera().done(function () { });
        VerificarEscanerDocumentos();
    });// Se ejecuta cuando el servicio se inicia
});