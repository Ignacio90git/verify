angular.module('myApp').controller('ControllerInicioVerificacionFacialMotor', function ($scope, bcstorage, biocheck) {
    $(".sub-header__listaPasos").html("<ul>" +
        "<li class='activo' id ='paso1'>" +
        "   1" +
        "</li >" +
        "<li class='desactivado' id='paso2'>" +
        "   2" +
        "</li>" +
        "</ul>" +
        "<span id='nombrePasoActual'>Aviso de privacidad</span>");
    $(".subheader").css("display", "flex");
    $(".cliente").removeClass("desaparece");
    //Es para saber si ya cargó la página mediante un mensaje al parent del iframe
    postCancelarConteoller();
    //Controla la versión del front
    bcstorage.versionBiocheck = "1.4.9";
    bcstorage.versionSistema = "3.2.2.8";
    bcstorage.proceso = "verifica_motor";

    biocheck.checkService();
    $scope.procesando = biocheck.procesando;
    $scope.modalerrormensaje = biocheck.modalerrormensaje;
    $scope.modalerrormensaje2 = biocheck.modalerrormensaje2;
    $.connection.hub.url = bcstorage.hubUrl;
    //  $scope.cancelar = biocheck.cancelarSalir;
    bcstorage.issuper = false;
    $scope.cargaCompleta = true;
    $scope.cont = 0;
    var ejecutivo = null;
    var biochkHub = $.connection.biocheckHub;
    var winPros = null;
    //Variables reset escáner
    var intentosReiniciarEscaner = 0;
    var intentosResetEscanerDoc = 3;
    var esReintentoEscaner = false;



    //Variables reset escáner

    // Colocar imagen de dos_manos dependiendo de la ruta que exista
    var urlImage = "../verify/img/dos_manos.png";
    if (!biocheck.fileExists(urlImage)) {
        urlImage = "../img/dos_manos.png";
    }
    $("#img-dos-manos").attr("src", urlImage);

    $scope.enviarBandera = function () {
        //Lalo
        switch ($scope.bandera) {
            case "EXT":
                biochkHub.server.whiteList("400");
                break;
            case "INE":
                biochkHub.server.whiteList("300");
                break;
            case "DFT":
                biochkHub.server.whiteList("600");
                break;
            case "NDR":
                biochkHub.server.whiteList("200");
                break;
        }
    };

    var guid = null;
    function VerificarToken() {
        winPros = $scope.procesando("Captura rostro");
        winPros.open();
        if (true) {
            var testtoken = $scope.getParameterByName('testtoken');
            if (bcstorage.token)
                if (bcstorage.token != "" && bcstorage.token != null) {
                    bcstorage.successToken = true;
                    buscarTipoToken();
                    //biochkHub.server.verifyToken(bcstorage.token);
                }
                else {
                    if (testtoken == "false") {
                        bcstorage.successToken = true;
                        buscarTipoToken();
                        //biochkHub.server.verifyToken(bcstorage.token);
                    }
                    else {
                        bcstorage.proceso = false;
                        bcstorage.codigoflujo = "ETO06";
                        biochkHub.server.getFinalDate();
                    }
                }
            else {
                if (testtoken == "false") {
                    bcstorage.successToken = true;
                    buscarTipoToken();
                    //biochkHub.server.verifyToken(bcstorage.token);
                }
                else {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "ETO06";
                    biochkHub.server.getFinalDate();
                }
            }
        }
    }

    function IsJsonString(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }

    function buscarTipoToken() {
        var datosCanal = null;
        var tipoToken = bcstorage.tipoToken;
        var tokenString = bcstorage.token;

        if (typeof bcstorage.token === 'string' && IsJsonString(bcstorage.token)) {
            datosCanal = JSON.parse(bcstorage.token);
        } else if (typeof bcstorage.token === 'object') {
            datosCanal = bcstorage.token;
        }
        if (datosCanal != null) {
            if (typeof datosCanal.tipoToken != "undefined" && datosCanal.tipoToken != "")
                tipoToken = datosCanal.tipoToken;
            if (typeof datosCanal.token != "undefined" && datosCanal.token != "")
                tokenString = datosCanal.token;
        } else {
            tipoToken = bcstorage.tipoToken;
            tokenString = bcstorage.token;
        }

        if (tipoToken == 'muro') {
            console.log('==>Verificacion de token Muro[' + tokenString + ']');
            biochkHub.server.verifyToken(tokenString);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
        } else
            if (tipoToken == 'tot') {
                console.log('==>Verificacion de token Transversal[' + tokenString + ']');
                biochkHub.server.verifyTokenTransversal(tokenString);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
            } else {
                console.log('==>Verificacion de token[' + tokenString + ']');
                biochkHub.server.verifyToken(tokenString);//Regreso (6.A)biochkHub.client.isSuperUser, (6.B)biochkHub.client.successToken,
            }
    }


    function onDevicesSuccess() {
        biochkHub.server.transactionID();
        biochkHub.server.pE68Consultar();
    }


    function ControladorFunciones(id, parametrosEntrada) {
        var funcion = {
            Id: id,
            ParametrosEntrada: parametrosEntrada
        };

        biochkHub.server.procesador(funcion);
    }

    function ActivarModoManualEscaner() {
        ControladorFunciones("ActivarModoManualEscaner", {});
    }

    ///////////////// funciones de respuesta del signalr ////////////////////////////


    if (biochkHub != undefined) {
        biochkHub.client.urlFrontResponse = function () {
            //init frontresponse
        }
        biochkHub.client.eraseBiometricsResponse = function () {
            //biochkHub.server.urlFront(window.location.href);
        }



        biochkHub.client.isSuperUser = function () {
            bcstorage.issuper = true;
        }

        biochkHub.client.showPreview = function (img) {
            $('#preview').css('opacity', '1');
            document.getElementById("preview").src = "data:image/png;base64," + img;
            document.getElementById("preview").src = "data:image/png;base64," + img;
        };

        biochkHub.client.facialChances = function (intentos) {
            $scope.intentosModalEjecutivo = "El ejecutivo tiene " + intentos + " intento(s)";
            ejecutivo = biocheck.modalejecutivo($scope.intentosModalEjecutivo);
            ejecutivo.open();
            //$("#msjErrorHuellaEjecutivo").text($scope.intentosModalEjecutivo);
            biochkHub.server.addFingerEjecutivo(guid, 2);
        };


        biochkHub.client.successEjecutivo = function () {
            $('.imgprevmodal').css('box-shadow', 'inset 3px 2px 5px 0 #63BA68');
            setTimeout(function () {
                ejecutivo.close();
                $scope.enviarBandera();
            }, 2000);
        };

        biochkHub.client.guid = function (guidHub) {
            guid = guidHub;
        };

        var repetir = function () {
            winPros = biocheck.procesando("Captura identificacion");
            winPros.open();
            VerificarEscanerDocumentos();
        }
        var CameraNotFound = function (code, message) {
            if (winPros) winPros.close();
            //$("#btniniciar").css("display", "none");
            if (parseInt(code) == 310) {
                $scope.modalerrormensaje2("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>", "Repetir", $scope.errorCamera, $scope.cancelarinfo);
            }

        }

        biochkHub.client.fail = function (code, message) {
            if (winPros) winPros.close();
            //$("#btniniciar").css("display", "none");
            if (ejecutivo) {
                $("#capexitosaejcutivo").text("Captura no exitosa");
                $('.imgprevmodal').css('box-shadow', 'inset 3px 2px 5px 0 #ec0000');
            }
            if (parseInt(code) == 310) {
                $scope.modalerrormensaje2("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones de la c\u00E1mara<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/camara_conexion.png'></div>", "Repetir", $scope.errorCamera, $scope.cancelarinfo);
            } else if (parseInt(code) == 320)
                $scope.modalerrormensaje2("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/lector_conexion.png'></div>", "Repetir", $scope.error, $scope.cancelarinfo);
            else if (parseInt(code) == 330) {
                $scope.modalerrormensaje2("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Repetir", repetir, $scope.cancelarinfo);
            }
            else if (parseInt(code) >= 100 && parseInt(code) < 200)
                $scope.modalerrormensaje("Error inesperado en la lectura de licencias. Código: " + parseInt(code), "Salir", $scope.errorlicencias);
            else if (parseInt(code) === 331)
                $scope.modalerrormensaje("Servicio de escaneo de documentos no pudo ser iniciado.", "Salir", $scope.errorServiciosEscaner);
            else if (parseInt(code) === 332) {
                $scope.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", errorServiciosEscaner);
            }
            else if (parseInt(code) === 333) {
                //Si hay intentos, verifica el estatus del escáner
                if (intentosReiniciarEscaner < intentosResetEscanerDoc) {
                    //Incrementa los intentos en 1
                    intentosReiniciarEscaner++;
                    esReintentoEscaner = true;
                    $scope.modalerrormensaje2("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Repetir", $scope.error, $scope.cancelarinfo);
                }
                else {//Si no hay intentos, notifica y termina flujo
                    $scope.modalerrormensaje("<div style='padding-left: 40px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de documentos<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/escaner_conexion.png'></div>", "Salir", errorServiciosEscaner);
                }
            }
            else if (parseInt(code) === 350)
                $scope.modalerrormensaje(message, "Salir", $scope.errorServiciosEscaner);
            else {
                setTimeout(function () {
                    if (ejecutivo)
                        ejecutivo.close();
                    if (parseInt(code) == 270) {
                        $scope.modalerrormensaje("Mala calidad en huella.", "Repetir", $scope.errorEjecutivo);
                    } else if (parseInt(code) == 300) {
                        $scope.modalerrormensaje("<div style='padding-left: 20px; float: left;'><img style='height: 65px;' alt='Alerta' src='img/advertencia.png'></div><div style='text-align: left; float: left;'>Comprueba conexiones del esc\u00E1ner de huellas<br>Si el error persiste, comun\u00EDcate al Service Desk 70767 opci\u00F3n #5</div><div style='padding-top: 100px;'><img style='height: 300px;' alt='Instrucciones.png' src='img/error/lector_conexion.png'></div>", "Repetir", $scope.errorEjecutivo);
                    } else if (parseInt(code) == 200) {
                        $scope.modalerrormensaje("El tiempo para realizar la captura se ha excedido, por favor repítela.", "Repetir", $scope.errorEjecutivo);
                    } else if (parseInt(code) == 280) {
                        $scope.modalerrormensaje("La captura ha excedido el número de intentos no es posible concluir el proceso de registro.", "Salir", $scope.errorEjecutivoFinal);
                    } else {
                        $scope.modalerrormensaje("Ocurrió un error inesperado en la captura de huellas.", "Repetir", $scope.errorEjecutivo);
                    }
                }, 2000);
            }
        };

        biochkHub.client.setBucAnonimizada = function (bucAnonimizada) {
            bcstorage.bucAnonimizada = bucAnonimizada;


        }; //Obtenemos la buc anonimizada del cliente

        biochkHub.client.successToken = function (response) {
            try { bcstorage.tokenBase64 = response.Datos.stokenValidatorResponse.pAdicional; } catch (errorTokenBase64) { bcstorage.tokenBase64 = ""; }
            var code = response.CodigoEstatus;
            switch (code) {
                case 1:
                    bcstorage.biometricId = response.biometricId;
                    if (bcstorage.biometricId != null && bcstorage.biometricId != '' && bcstorage.biometricId != undefined) {
                        console.info('pycaso envio biometricID: ' + bcstorage.biometricId);
                    }
                    biochkHub.server.checkIfCameraIsConected().done(function (result) {
                        if (result) {
                            onDevicesSuccess();
                        } else {
                            CameraNotFound(310);
                        }
                    });
                    break;
                case 2:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(biocheck.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones), "Salir", $scope.errorToken, response.CodigoError);
                    break;
                case 3:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(response.Mensaje, "Salir", $scope.errorToken, response.CodigoError);
                    break;
                case 4:
                    bcstorage.codigoflujo = response.CodigoError;
                    $scope.modalerrormensaje(response.Mensaje, "Salir", $scope.errorToken, response.CodigoError);
                    break;
                default:
                    $scope.modalerrormensaje("Ocurrió un error en la validación de token.", "Salir", $scope.errorToken);
            }

        }
        biochkHub.client.biocheckEjecutaBat = function (response) {
            VerificarEscanerDocumentos();

        }

        biochkHub.client.failToken = function () {
            if (winPros) winPros.close();
            $scope.modalerrormensaje("Ocurrió un error en la validación de token.", "Salir", $scope.errorToken);
        }

        biochkHub.client.consultResponse = function (response) {

            if (parseInt(response.code) == 0) {
                if (response.result.enrollmentStatus != "" && response.result.enrollmentStatus != null && response.result.enrollmentStatus != "NO_ENROLADO" && response.result.enrollmentStatus != "BAJA") {
                    $scope.modalerrormensaje("El cliente/empleado ya está enrolado.", "Salir", $scope.errorConsult);
                }
                else {
                    if (response.result.employeeId != null && response.result.employeeId != "")
                        bcstorage.esEmpleado = true;
                    else
                        bcstorage.esEmpleado = false;

                    biochkHub.server.transactionID();
                    //biochkHub.server.getDataCustomer2();
                    biochkHub.server.consultarAPI_Customer();
                }

            }
            else {
                if (response.code == 400) {
                    var obj = JSON.parse(response.message);
                    if (obj.errores)
                        if (obj.errores.length > 0) {
                            bcstorage.proceso = false;
                            bcstorage.codigoflujo = obj.errores[0].code;
                            bcstorage.mensajeflujo = obj.errores[0].message;
                            bcstorage.mensajeinternoflujo = obj.errores[0].description;
                        }
                    if (obj.errors)
                        if (obj.errors.length > 0) {
                            bcstorage.proceso = false;
                            bcstorage.codigoflujo = obj.errors[0].code;
                            bcstorage.mensajeflujo = obj.errors[0].message;
                            bcstorage.mensajeinternoflujo = obj.errors[0].description;
                        }
                }
                else if (response.code == 404) {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "ECC01";
                }
                else {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "ECC00";
                }
                biochkHub.server.getFinalDate();
            }
        }

        biochkHub.client.consultaEmpleadoResponse = function (response) {

            var code = response.CodigoEstatus;
            switch (code) {
                case 1:
                    if (response.Datos.enrollmentStatus != "" && response.Datos.enrollmentStatus != null && response.Datos.enrollmentStatus != "NO_ENROLADO" && response.Datos.enrollmentStatus != "BAJA") {
                        bcstorage.dedosEjecutivo = response.Datos.fingersAvailable;
                        biochkHub.server.transactionID();
                        biochkHub.server.consult();
                    }
                    else {
                        $scope.modalerrormensaje("<strong>Estimado usuario,</strong></br> No se encuentra registrado biométricamente, </br>razón por la cual no es posible continuar con el proceso.", "Finalizar", $scope.errorConsultNoEnrolado);
                    }
                    break;
                case 2:
                    $scope.modalerrormensaje(biocheck.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones), "Ok", $scope.errorConstEmple, response.CodigoError);
                    break;
                case 3:
                    $scope.modalerrormensaje(response.Mensaje, "Ok", $scope.errorConstEmple, response.CodigoError);
                    break;
                case 4:
                    $scope.modalerrormensaje(response.Mensaje, "Ok", $scope.errorConstEmple, response.CodigoError);
                    break;
                default:
                    $scope.modalerrormensaje("Ocurrió un error en la consulta biometrica del empleado supervisor.", "Ok", $scope.errorConstEmple);
            }
        }

        biochkHub.client.pE68GuardarRespuesta = function (response) {
            var code = response.CodigoEstatus;
            var errorcustom = false;
            if (winPros)
                winPros.close();
            //Se pone el codigo de estatus de la petición REST independientemente del código de estatus de manejo interno
            var codigoEstatusRespuesta = "";
            if ((response.Datos != null && response.Datos != undefined) && (response.Datos.status != null && response.Datos.status != undefined)) {
                codigoEstatusRespuesta = response.Datos.status.statusCode;
            }
            else {
                codigoEstatusRespuesta = response.Mensaje
            }
            switch (code) {
                case 1:
                    if (response.Datos.status.statusCode == 0 && response.Datos.partyRec.partyInfo.personPartyInfo != null) {
                        var cData = response.Datos.partyRec.partyInfo.personPartyInfo;
                        bcstorage.apicNombre = cData.personName.givenName || '';
                        bcstorage.apicApellidoP = cData.personName.paternalName || '';
                        bcstorage.apicApellidoM = cData.personName.maternalName || '';
                        bcstorage.nombreCliente = bcstorage.apicNombre + " " + bcstorage.apicApellidoP + " " + bcstorage.apicApellidoM;
                        $scope.NombreCli = bcstorage.nombreCliente;
                        $("#nombreCliente").text("Cliente: " + bcstorage.nombreCliente);
                        $("#NombreClienteINE").html(bcstorage.nombreCliente);
                        $scope.tipoCliente = $scope.NombreCli;
                        if (cData.birthDt) {
                            if (cData.birthDt != null && cData.birthDt != "") {
                                if (typeof cData.birthDt != undefined) {
                                    var btDate = cData.birthDt.split("-");
                                    bcstorage.apicDia = btDate[2];
                                    bcstorage.apicMes = btDate[1];
                                    bcstorage.apicAno = btDate[0];
                                }
                            }
                        }
                        bcstorage.apicSexo = cData.gender == "MASCULINO" ? "H" : "M";
                        //bcstorage.apicNac = cData.birthPlace == "MEXICO";
                    }
                    else if (response.Datos.status.statusCode == 100) {
                        biocheck.modalerrormensaje("Ocurrió un error en la consulta del cliente.", "Salir", function () {
                            $scope.errorConstEmple();
                        });
                    }
                    else {
                        /*Si el estatus de la respuesta que devuelve la API es fallido,
                        muestra mensaje y termina el flujo.*/
                        bcstorage.codigoflujo = "EPE6801";
                        var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                        biocheck.modalerrormensaje(msjError, "Salir", function () { biochkHub.server.getFinalDate() });
                    }
                    break;
                case 2:
                    bcstorage.codigoflujo = response.CodigoError;
                    var flagbuc = false;
                    $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
                        if (value.indexOf("customer does not exist") != -1)
                            flagbuc = true;
                    });
                    if (flagbuc) {
                        var msjFinal = "";
                        $.each(response.ExcepcionSumarizada.Excepciones, function (key, value) {
                            msjFinal += key;
                        });
                        $scope.modalerrormensaje(msjFinal, "Salir", $scope.errorGeneral, response.CodigoError);
                    }
                    else
                        $scope.modalerrormensaje(biocheck.msjExcepcionSumarizada(response.Mensaje, response.ExcepcionSumarizada.Excepciones), "Salir", $scope.errorGeneral, response.CodigoError);
                    break;
                case 3:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;
                case 4:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;
                default:
                    bcstorage.codigoflujo = "EPE6802";
                    var msjError = biocheck.codigoError(bcstorage.codigoflujo);
                    biocheck.modalerrormensaje(msjError + " " + codigoEstatusRespuesta, "Salir", function () { biochkHub.server.getFinalDate() });
                    break;

            }
        }

        biochkHub.client.enrollResponse = function (response) {
            //alert(response);

            //d.close();
            winPros.close();
            if (response.code == 0) {

                if (response.result) {
                    if (response.result.code === "PRC00") {
                        bcstorage.proceso = true;
                        bcstorage.codigoflujo = response.result.code;
                        bcstorage.mensajeflujo = response.result.message;
                    }
                    else {
                        bcstorage.proceso = false;
                        bcstorage.codigoflujo = response.result.code;
                        bcstorage.mensajeflujo = response.result.message;
                    }
                }
            }
            else {
                if (response.code == 400) {
                    var obj = JSON.parse(response.message);
                    if (obj.errores)
                        if (obj.errores.length > 0) {
                            bcstorage.proceso = false;
                            bcstorage.codigoflujo = obj.errores[0].code;
                            bcstorage.mensajeflujo = obj.errores[0].message;
                            bcstorage.mensajeinternoflujo = obj.errores[0].description;
                        }
                    if (obj.errors)
                        if (obj.errors.length > 0) {
                            bcstorage.proceso = false;
                            bcstorage.codigoflujo = obj.errors[0].code;
                            bcstorage.mensajeflujo = obj.errors[0].message;
                            bcstorage.mensajeinternoflujo = obj.errors[0].description;
                        }
                }
                else if (response.code == 404) {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "EEB01";
                }
                else {
                    bcstorage.proceso = false;
                    bcstorage.codigoflujo = "EEB00";
                }
            }
            biochkHub.server.getFinalDate();
        }
        $scope.errorGeneral = function (codigoError) {
            bcstorage.apicNombre = "";
            bcstorage.apicApellidoP = "";
            bcstorage.apicApellidoM = "";
            bcstorage.proceso = false;
            //bcstorage.codigoflujo = codigoError;
            biochkHub.server.getFinalDate();
        };
        $scope.onFinalizarFlujo = function (hora, fecha, trasaction) {
            if (winPros) winPros.close();
            bcstorage.fechapros = fecha;
            bcstorage.horapros = hora;
            bcstorage.foliopros = trasaction;
            if (biocheck.codigoError(bcstorage.codigoflujo) != '0')
                bcstorage.mensajeflujo = biocheck.codigoError(bcstorage.codigoflujo);
            biocheck.onStopSignalR();
            $(location).attr('href', '#!/finalizar');
        };

        biochkHub.client.finalDate = function (hora, fecha, trasaction) {
            $scope.onFinalizarFlujo(hora, fecha, trasaction);
        }

        biochkHub.client.successConfig = function () {
            redireccionar();
        }

        biochkHub.client.configuracionRespuesta = function (respuesta) {
            var versionSistema = '';
            if (respuesta.VersionSistema != null && respuesta.VersionSistema != undefined && respuesta.VersionSistema != '') {
                versionSistema = respuesta.VersionSistema;
            }
            bcstorage.OmitirVigenciaIne = false;
            if (respuesta.OmitirVigenciaIne != null && respuesta.OmitirVigenciaIne != undefined && respuesta.OmitirVigenciaIne != '') {
                bcstorage.OmitirVigenciaIne = respuesta.OmitirVigenciaIne;
                bcstorage.EstadosVigenciaIne = respuesta.EstadosVigenciaIne;
            }

            //Si el BWS no es capaz de entregar la versión del sistema o si la entrega y esta es diferente a la declarada en el front, redirecciona.
            if (versionSistema == '' || versionSistema != bcstorage.versionSistema) {

                redireccionar();
            }
            else {
                if (bcstorage.successToken == undefined || bcstorage.successToken == false) {
                    console.log("se procede a verificar el token");
                    VerificarToken();
                }
            }
        }

        biochkHub.client.setRedirectUrl = function (resultUrl) {
            setTimeout(function () {
                if (winPros)
                    winPros.close(); //Se debe cerrar el modal
                biocheck.onStopSignalR(); //Se debe cerrar la comunición
                var urlParams = "Ejecutivo";
                var hashSymbol = true;
                var targetUrl = resultUrl + (hashSymbol == true ? "/#!/" : "/") + urlParams;
                window.location.replace(targetUrl);
            }, 3000);
        };//Redirecciona a otra version

        var redireccionar = function () {
            biochkHub.server.getFrontUrl("verify", true);
        }



        biochkHub.client.obtenerVersionDespliegue = function (respuesta) {
            var obtenerVersionDespliegueExito = true;
        }

        biochkHub.client.failConfig = function () {
            if (winPros) winPros.close();
            $scope.modalerrormensaje("Ocurrió un error en la consulta de configuración.", "Salir", $scope.errorConfig);
        }


        biochkHub.client.biocheckVersionInstalador = function (response) {
            bcstorage.versionInstalador = response;
            $(".versionInstalador").text(response);
        };

        biochkHub.client.initPeticionIneSimple = function (response) {
            winPros = biocheck.procesando("Datos en proceso");
            winPros.open();
        }
        biochkHub.client.ineFacialMotorResponse = function (response) {
            console.log("ENTRORESPONSEINEFCIAL");
            $scope.yaFueAlIne = true;
            var mensajeError = "";
            var mensajeScore1 = "";
            var mensajeScore2 = "";

            bcstorage.hash = "";
            if (winPros)
                winPros.close(); //Se debe cerrar el modal

            if (response.partyAuthRec != null) {
                if (response.partyAuthRec.partyAuthInfo != null) {
                    if (response.partyAuthRec.partyAuthInfo.bioScore != null) {
                        if (response.partyAuthRec.partyAuthInfo.bioScore.ResponseHash != null) {
                            bcstorage.hash = response.partyAuthRec.partyAuthInfo.bioScore.ResponseHash;

                            if (response.partyAuthRec.partyAuthInfo.bioScore.MatchResponse == "I") {
                                bcstorage.proceso = true;
                                bcstorage.codigoflujo = "OKM000";
                                bcstorage.mensajeflujo = "Validación Correcta";
                                biochkHub.server.getFinalDate();
                            }
                            else {

                                $scope.errorINEFacial();
                            }
                        }
                    }

                }
            }
            else {
                $scope.errorINEFacial();
            }
            /*
                        if (response.idvCheck != null) {
                            if (response.idvCheck.dataVerification != null) {
                                if (response.idvCheck.dataVerification.operationData != null) {
                                    if (response.idvCheck.dataVerification.operationData.data != null) {
                                        bcstorage.hash = response.idvCheck.dataVerification.operationData.data;
                                    }
                                }
                            }
                            if (response.idvCheck.biometricVerification!=null) {
                                if (response.idvCheck.biometricVerification.verificationResult != null) {
                                    if (response.idvCheck.biometricVerification.verificationResult.result == "HIT") {
                                        bcstorage.proceso = true;
                                        bcstorage.codigoflujo = "OK0000";
                                        bcstorage.mensajeflujo = "Validación Correcta";
                                        biochkHub.server.getFinalDate();
                                    }
                                    else if (response.idvCheck.biometricVerification.verificationResult.result == "NOHIT") {
            
                                        if (response.idvCheck.biometricVerification.verificationResult.reasonDescription != null || response.idvCheck.biometricVerification.verificationResult.reasonDescription != "") {
                                            //SACAMOS LAS RAZON DESCRIPTION
                                            mensajeError = response.idvCheck.biometricVerification.verificationResult.reasonDescription;
                                          
                                        }
            
                                        if (response.idvCheck.biometricVerification.verificationResult.reasons != null) {
                                            if (response.idvCheck.biometricVerification.verificationResult.reasons.length > 0) {
                                                mensajeScore1 = response.idvCheck.biometricVerification.verificationResult.reasons[0].reasonDescription;
                                            }
            
                                            if (response.idvCheck.biometricVerification.verificationResult.reasons.length > 1) {
                                                mensajeScore2 = response.idvCheck.biometricVerification.verificationResult.reasons[1].reasonDescription;
                                            }
                                        }
            
            
                                        $scope.errorINEFacial();
            
                                    }
                                }
                            }
                        };
            */
        };

    }

    $scope.errorINEFacial = function () {
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EVDF03";
        biochkHub.server.getFinalDate();
    };

    $scope.errorConstEmple = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "CS001";
        biochkHub.server.getFinalDate();
    }
    $scope.errorConfig = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "CS001";
        biochkHub.server.getFinalDate();
    }
    $scope.error = function () {
        winPros = $scope.procesando("Cargando datos");
        winPros.open();

        $scope.cont = 0;
    };
    $scope.errorCamera = function () {
        winPros = $scope.procesando("Captura rostro");
        winPros.open();
        checkDiconnectedCamera();
        $scope.cont = 0;
    };

    $scope.cancelarinfo = function () {
        bcstorage.proceso = true;
        bcstorage.codigoflujo = "CA000";
        biochkHub.server.getFinalDate();
    }

    //Función para error en los servicios del escaner de documentos
    $scope.errorServiciosEscaner = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "ELB01";
        biochkHub.server.getFinalDate();
    };

    $scope.errorEjecutivo = function () {
        biochkHub.server.getFacialChances();
    };

    $scope.errorEjecutivoFinal = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EOB00";
        biochkHub.server.getFinalDate();
    };

    function checkDiconnectedCamera() {
        var retriesCheckCamera = 0;
        var intervalId = window.setInterval(function () {
            biochkHub.server.checkIfCameraIsConected().done(function (result) {
                if (winPros)
                    winPros.close();
                winPros = biocheck.procesando("Captura rostro");
                winPros.open();
                if (result) {
                    clearInterval(intervalId);
                    if (winPros)
                        winPros.close();
                } else {
                    retriesCheckCamera++;

                }
                if (retriesCheckCamera == 3) {
                    retriesCheckCamera = 0;
                    clearInterval(intervalId);
                    CameraNotFound(310);
                }
            });
        }, 3000);
    }


    function startSignalR() {
        biochkHub.server.eraseBiometrics();
        //winPros = $scope.procesando("Captura rostro");
        //winPros.open();

        var urlpag = window.location.href;
        biochkHub.server.urlFront(urlpag);
        biochkHub.server.obtenerVersionDespliegue();
        biochkHub.server.getBiocheckVersion(bcstorage.versionBiocheck, bcstorage.versionSistema);
        biochkHub.server.setConfigData();
        $(".versionBiocheck").text(bcstorage.versionBiocheck);


        //CameraNotFound(310);

    }

    biocheck.onStartSignalR(startSignalR);
    $.connection.hub.reconnecting(function () {
        //No es necesario una funcionalidad aquí
    });

    // reconnected the connection.
    $.connection.hub.reconnected(function () {
        //No es necesario una funcionalidad aquí
    });

    $.connection.hub.disconnected(function () {
        //No es necesario una funcionalidad aquí
    });

    $scope.errorConsult = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EEB02";
        biochkHub.server.getFinalDate();
    };

    $scope.errorConsultNoEnrolado = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EEB03";
        biochkHub.server.getFinalDate();
    };

    $scope.errorCustomers = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EAC01";
        biochkHub.server.getFinalDate();
    };

    $scope.errorCustomersBuc = function () {
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        bcstorage.proceso = false;
        bcstorage.codigoflujo = "EAC03";
        biochkHub.server.getFinalDate();
    };

    $scope.errorToken = function () {
        if (winPros) winPros.close();
        bcstorage.proceso = false;
        bcstorage.apicNombre = "";
        bcstorage.apicApellidoP = "";
        bcstorage.apicApellidoM = "";
        //bcstorage.codigoflujo = "ETO01";
        biochkHub.server.getFinalDate();
    };

    $scope.getParameterByName = function (name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.href);
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    $scope.salir = function () {
        c.open();
    };
    $scope.reiniciar = function () {
        biocheck.nuevopaso(1);
    };
    $scope.reiniciar();
    $scope.iniciar = function () {
        biocheck.onStopSignalR();
        $(location).attr('href', '#!/NoEnrolado/facialIneRostroCaptura');
    };

    $scope.cancelar = function () {
        biocheck.cancelar(function () {
            $scope.error("CA000", "Proceso cancelado")
        });
    };

    $scope.error = function (codigoError) {
        bcstorage.codigoflujo = codigoError;
        codigoError === "CA000" ? bcstorage.proceso = true : bcstorage.proceso = false;
        biochkHub.server.getFinalDate();
    };

    $scope.cancelarinfo = function () {
        bcstorage.proceso = true;
        bcstorage.codigoflujo = "CA000";
        biochkHub.server.getFinalDate();
    };

    $scope.validar2 = function () {
        biochkHub.server.testFacialPeticion();
    }

});
