module.exports = function(s) {
    "use strict";
    require("load-grunt-tasks")(s);
    s.initConfig({
        pkg: s.file.readJSON("package.json"),
        jshint: {
            files: ["Gruntfile.js", "src/**/*.js", "test/**/*.js"]
        },
        clean: ["dist/**/*"],
        copy: {
            main: {
                files: [{
                    expand: !0,
                    cwd: "node_modules/bootstrap/dist/js",
                    src: "bootstrap*.js",
                    dest: "src/js/vendor/"
                }, {
                    expand: !0,
                    cwd: "node_modules/bootstrap/dist/css",
                    src: "bootstrap.css",
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/font-awesome/css",
                    src: "font-awesome.css",
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/font-awesome/fonts",
                    src: "*.*",
                    dest: "dist/fonts"
                }, {
                    expand: !0,
                    cwd: "node_modules/less-prefixer",
                    src: "prefixer.less",
                    dest: "src/css/less"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular",
                    src: "angular*.js",
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-route",
                    src: "angular-route*.js",
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-messages",
                    src: "angular-messages*.js",
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-animate",
                    src: "angular-animate*.js",
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/ngstorage",
                    src: "ngStorage*.js",
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-strap/dist",
                    src: ["angular-strap.js", "angular-strap.min.js", "angular-strap.tpl.js", "angular-strap.tpl.min.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-motion/dist",
                    src: ["angular-motion.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/bootstrap-additions/dist",
                    src: ["bootstrap-additions.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/jquery/dist",
                    src: ["jquery.js", "jquery.min.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/animate.css",
                    src: ["animate.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/d3/build",
                    src: ["d3.min.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/datatables.net/js",
                    src: ["jquery.dataTables.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/datatables.net-dt/css",
                    src: ["jquery.dataTables.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-datatables/dist",
                    src: ["angular-datatables*.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-datatables/dist/css",
                    src: ["angular-datatables*.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-datatables/dist/plugins/bootstrap",
                    src: ["angular-datatables.bootstrap*.js"],
                    dest: "src/js/vendor"
                }, {
                    expand: !0,
                    cwd: "node_modules/angular-datatables/dist/plugins/bootstrap",
                    src: ["datatables.bootstrap.min.css"],
                    dest: "src/css/"
                }, {
                    expand: !0,
                    cwd: "node_modules/file-saver",
                    src: ["FileSaver*.js"],
                    dest: "src/js/vendor"
                }]
            },
            jenkins: {
                files: [{
                    expand: !0,
                    src: ["*.html"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["vistas/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["vendor/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["js/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["img/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["css/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["conf.d/**"],
                    dest: "dist/"
                }, {
                    expand: !0,
                    src: ["health"],
                    dest: "dist/"
                }]
            },
            jenkinscaas: {
                files: [{
                    expand: !0,
                    src: ["*.html"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["vistas/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["vendor/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["js/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["img/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["css/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["conf.d/**"],
                    dest: "dist/biocheck/verify/"
                }, {
                    expand: !0,
                    src: ["health"],
                    dest: "dist/biocheck/verify/"
                }]
            },
            dev: {
                files: [{
                    expand: !0,
                    cwd: "src/js/vendor",
                    src: ["*.js", "!*.min.js"],
                    dest: "dist/js/"
                }]
            },
            dist: {
                files: [{
                    expand: !0,
                    cwd: "src/js/vendor",
                    src: "*.min.js",
                    dest: "dist/js/"
                }]
            }
        },
        concat: {
            options: {
                separator: ";;;"
            },
            dist: {
                files: {
                    "dist/js/<%= pkg.name %>.js": ["src/**/*.js", "!src/js/vendor/**/*.js"]
                }
            }
        },
        uglify: {
            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n'
            },
            dist: {
                files: {
                    "dist/js/<%= pkg.name %>.min.js": "dist/js/<%= pkg.name %>.js"
                }
            }
        },
        less: {
            development: {
                files: [{
                    expand: !0,
                    cwd: "src/css/less",
                    src: ["*.less"],
                    dest: "src/css/",
                    ext: ".css"
                }]
            }
        },
        cssmin: {
            dist: {
                files: {
                    "dist/css/<%= pkg.name %>.min.css": "src/css/**/*.css"
                }
            }
        },
        stripCssComments: {
            options: {
                preserve: !1
            },
            dist: {
                files: {
                    "dist/css/<%= pkg.name %>.min.css": "dist/css/<%= pkg.name %>.min.css"
                }
            }
        },
        usebanner: {
            taskName: {
                options: {
                    position: "top",
                    banner: '/*! <%= pkg.name %> <%= grunt.template.today("dd-mm-yyyy") %> */\n',
                    linebreak: !0
                },
                files: {
                    src: ["dist/css/<%= pkg.name %>.min.css"]
                }
            }
        },
        htmlmin: {
            dist: {
                options: {
                    removeComments: !0,
                    collapseWhitespace: !0,
                    minifyCSS: !0,
                    minifyJS: !0
                },
                files: [{
                    expand: !0,
                    cwd: "dist/",
                    src: "**/*.html",
                    dest: "dist"
                }]
            }
        },
        imagemin: {
            dynamic: {
                files: [{
                    expand: !0,
                    cwd: "src/images",
                    src: ["**/*.{png,jpg,gif}"],
                    dest: "dist/images"
                }, {
                    expand: !0,
                    cwd: "src/img",
                    src: ["**/*.{png,jpg,gif}"],
                    dest: "dist/img"
                }]
            }
        },
        htmlbuild: {
            dev: {
                src: "src/**/*.html",
                dest: "dist/",
                beautify: !0,
                prefix: "",
                relative: !0,
                options: {
                    data: {
                        appName: ""
                    },
                    basePath: "/src",
                    scripts: {
                        bundle: ["dist/js/jquery.js", "dist/js/angular.js", "dist/js/angular-route.js", "dist/js/angular-animate.js", "dist/js/angular-messages.js", "dist/js/ngStorage.js", "dist/js/bootstrap.js", "dist/js/angular-strap.js", "dist/js/angular-strap.tpl.js", "dist/js/d3.min.js", "dist/js/jquery.dataTables.js", "dist/js/angular-datatables.js", "dist/js/angular-datatables.bootstrap.js", "dist/js/FileSaver.js", "dist/js/sockjs.js", "dist/js/bootstrap-notify.js", "dist/js/captureStatus.js", "dist/js/fingers.js", "dist/js/biolink.js"],
                        main: "dist/js/<%= pkg.name %>.js"
                    },
                    styles: {
                        main: "dist/css/<%= pkg.name %>.min.css"
                    }
                }
            },
            dist: {
                src: "src/**/*.html",
                dest: "dist/",
                prefix: "",
                relative: !0,
                options: {
                    basePath: "/src",
                    data: {
                        appName: "admin"
                    },
                    scripts: {
                        bundle: ["dist/js/jquery.min.js", "dist/js/angular.min.js", "dist/js/angular-route.min.js", "dist/js/angular-animate.min.js", "dist/js/angular-messages.min.js", "dist/js/ngStorage.min.js", "dist/js/bootstrap.min.js", "dist/js/angular-strap.min.js", "dist/js/angular-strap.tpl.min.js", "dist/js/d3.min.js", "dist/js/jquery.dataTables.min.js", "dist/js/angular-datatables.min.js", "dist/js/angular-datatables.bootstrap.min.js", "dist/js/FileSaver.min.js", "dist/js/sockjs.min.js", "dist/js/bootstrap-notify.min.js", "dist/js/captureStatus.min.js", "dist/js/fingers.min.js", "dist/js/biolink.min.js"],
                        main: "dist/js/<%= pkg.name %>.min.js"
                    },
                    styles: {
                        main: "dist/css/<%= pkg.name %>.min.css"
                    }
                }
            }
        },
        mkdir: {
            all: {
                options: {
                    create: ["dist/WEB-INF"]
                }
            }
        },
        connect: {
            server: {
                options: {
                    base: ".",
                    port: "8000",
                    open: !0,
                    keepalive: !0
                }
            }
        },
        compress: {
            build: {
                options: {
                    mode: "zip",
                    archive: "admin.war"
                },
                files: [{
                    expand: !0,
                    src: ["./**/*"],
                    cwd: "dist/"
                }]
            }
        },
        watch: {
            options: {
                livereload: !0
            },
            files: ["<%= jshint.files %>", "src/**/*.*"],
            tasks: ["devtime"]
        }
    }),
    s.registerTask("minify",
        "Todas las tareas de minificacion de archivos",
        ["concat", "uglify", "less", "cssmin", "stripCssComments", "usebanner", "imagemin"]),
    s.registerTask("devtime",
        "Solamente las tareas necesarias que se deben realizar en tiempo de desarrollo",
        ["jshint", "minify", "copy:dev", "htmlbuild:dev"]),
    s.registerTask("dist",
        "Default Task",
        ["jshint", "clean", "copy:main", "minify", "copy:dist", "htmlbuild:dist", "htmlmin"]),
    s.registerTask("default",
        "Default Task",
        ["copy:jenkins", "copy:jenkinscaas"])
};
