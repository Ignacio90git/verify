# biocheck-verify-front

Microservicio front de verificación biométrica